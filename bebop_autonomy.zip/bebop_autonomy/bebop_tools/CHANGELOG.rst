^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package bebop_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.0 (2017-07-29)
------------------

0.6.0 (2016-11-02)
------------------
* Added Xbox 360 config file
* Make flattrim joystick command match comment
* Contributors: Jacob Perron, Thomas Bamford

0.5.1 (2016-05-04)
------------------

0.5.0 (2016-04-01)
------------------
* Improve the organization of launch and param files
* Contributors: Mani Monajjemi

0.4.1 (2016-02-17)
------------------
* Update the joystick configuration file for taking snapshots
* Make bebop's namespace in joy_teleop launch file a parameter
* Contributors: Mani Monajjemi

0.4.0 (2016-01-17)
------------------
* Fix cmd_vel.linear.y sign issue in joystick config file
* Contributors: Mani Monajjemi

0.3.0 (2015-09-17)
------------------
* Renamed package to bebop_tools
* Contributors: Mani Monajjemi

0.2.0 (2015-09-10)
------------------
* Move image_view nodelet demo to bebop_tools package
* Contributors: Mani Monajjemi

0.1.2 (2015-09-05)
------------------
* Initial release of joystick teleop for bebop_autonomy
* Contributors: Mani Monajjemi

0.1.1 (2015-09-04)
------------------
